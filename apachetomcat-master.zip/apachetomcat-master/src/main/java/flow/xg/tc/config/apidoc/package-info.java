/**
 * Swagger api specific code.
 */
package flow.xg.tc.config.apidoc;