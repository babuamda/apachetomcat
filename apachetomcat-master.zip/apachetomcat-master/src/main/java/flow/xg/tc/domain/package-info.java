/**
 * JPA domain objects.
 */
package flow.xg.tc.domain;
