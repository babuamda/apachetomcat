/**
 * Async helpers.
 */
package flow.xg.tc.async;
