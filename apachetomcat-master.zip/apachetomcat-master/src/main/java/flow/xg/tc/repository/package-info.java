/**
 * Spring Data JPA repositories.
 */
package flow.xg.tc.repository;
