/**
 * Locale specific code.
 */
package flow.xg.tc.config.locale;
