/**
 * Data Transfer Objects used by Spring MVC REST controllers.
 */
package flow.xg.tc.web.rest.dto;
