/**
 * Service layer beans.
 */
package flow.xg.tc.service;
